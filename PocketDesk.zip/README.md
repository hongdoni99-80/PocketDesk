# 윈도우 데스크
GitHub에 올리면 Actions가 자동으로 APK를 빌드합니다.
1. 이 폴더의 파일을 전부(.github 폴더 포함) 새 저장소에 업로드
2. Actions 탭 > WindowDesk APK 실행 (push하면 자동 실행)
3. 완료된 실행 화면 맨 아래 Artifacts의 WindowDesk-APK 다운로드 > 압축 해제 > app-debug.apk 설치
4. 설치 후 앱에서 스위치를 켜거나 빠른 설정에 '데스크톱 모드' 타일 추가
