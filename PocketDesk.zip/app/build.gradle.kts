plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.windowdesk"
    compileSdk = 34
    defaultConfig { applicationId = "com.windowdesk"; minSdk = 26; targetSdk = 33; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
