package com.windowdesk

import android.content.Context
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*

/** 창 안에서 실행되는 기본 앱들 */
object Builtins {
    fun notepad(c: Context): View = EditText(c).apply {
        gravity = Gravity.TOP or Gravity.START; setBackgroundColor(-1); setTextColor(0xFF000000.toInt())
        hint = "메모를 입력하세요"; setPadding(24, 24, 24, 24)
    }

    fun calc(c: Context): View {
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF1E1E1E.toInt()) }
        val disp = TextView(c).apply { text = "0"; textSize = 32f; setTextColor(-1); gravity = Gravity.END or Gravity.CENTER_VERTICAL; setPadding(16, 16, 16, 16) }
        col.addView(disp, LinearLayout.LayoutParams(-1, 0, 1.2f))
        var acc = 0.0; var op = ""; var cur = ""
        fun fmt(d: Double) = if (d.isNaN()) "오류" else if (d == Math.floor(d) && Math.abs(d) < 1e12) d.toLong().toString() else d.toString()
        fun calc() {
            val v = cur.toDoubleOrNull() ?: return
            acc = when (op) { "+" -> acc + v; "-" -> acc - v; "×" -> acc * v; "÷" -> if (v == 0.0) Double.NaN else acc / v; else -> v }
            cur = ""
        }
        fun press(k: String) {
            when (k) {
                "C" -> { acc = 0.0; op = ""; cur = ""; disp.text = "0" }
                "=" -> { calc(); op = ""; disp.text = fmt(acc) }
                "+", "-", "×", "÷" -> { calc(); op = k; disp.text = fmt(acc) }
                "." -> if (!cur.contains(".")) { cur += if (cur.isEmpty()) "0." else "."; disp.text = cur }
                else -> { cur += k; disp.text = cur }
            }
        }
        val keys = listOf("7", "8", "9", "÷", "4", "5", "6", "×", "1", "2", "3", "-", "C", "0", ".", "+", "=")
        keys.chunked(4).forEach { row ->
            val r = LinearLayout(c)
            row.forEach { k -> r.addView(Button(c).apply { text = k; setOnClickListener { press(k) } }, LinearLayout.LayoutParams(0, -1, 1f)) }
            col.addView(r, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        return col
    }

    fun browser(c: Context): View {
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(c)
        val url = EditText(c).apply { setText("https://www.google.com"); setSingleLine(); setTextColor(0xFF000000.toInt()); setBackgroundColor(-1) }
        val go = Button(c).apply { text = "이동" }
        val wv = WebView(c).apply { settings.javaScriptEnabled = true; webViewClient = WebViewClient(); loadUrl("https://www.google.com") }
        go.setOnClickListener {
            var u = url.text.toString().trim()
            if (!u.startsWith("http")) u = if (u.contains(".") && !u.contains(" ")) "https://$u" else "https://www.google.com/search?q=" + Uri.encode(u)
            wv.loadUrl(u)
        }
        row.addView(url, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(go)
        col.addView(row); col.addView(wv, LinearLayout.LayoutParams(-1, 0, 1f))
        return col
    }
}
