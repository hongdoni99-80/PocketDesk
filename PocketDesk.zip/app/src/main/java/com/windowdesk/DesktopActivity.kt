package com.windowdesk

import android.app.Activity
import android.app.ActivityOptions
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class DesktopActivity : Activity() {
    companion object { var instance: DesktopActivity? = null }

    private lateinit var startMenu: ScrollView
    private lateinit var winLayer: FrameLayout
    private val wins = ArrayList<Win>()
    private var focusedWin: Win? = null
    private var wcount = 0
    private lateinit var tasks: LinearLayout
    private val opened = HashSet<String>()
    private var count = 0
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        instance = this
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        val apps = pm().queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(pm()).toString().lowercase() }

        val root = FrameLayout(this)
        root.background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF1B2A49.toInt(), 0xFF3A6EA5.toInt(), 0xFF6FB1C8.toInt()))

        // 바탕화면 아이콘
        val desk = GridLayout(this).apply { orientation = GridLayout.VERTICAL; rowCount = 5; setPadding(dp(12), dp(32), 0, 0) }
        builtins().forEach { desk.addView(it) }
        apps.take(7).forEach { desk.addView(cell(it, 0xFFFFFFFF.toInt())) }
        root.addView(desk, FrameLayout.LayoutParams(-2, -2))
        winLayer = FrameLayout(this)
        root.addView(winLayer, FrameLayout.LayoutParams(-1, -1).apply { bottomMargin = dp(52) })

        // 시작 메뉴
        val grid = GridLayout(this).apply { columnCount = 4; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        builtins().forEach { grid.addView(it) }
        apps.forEach { grid.addView(cell(it, 0xFFFFFFFF.toInt())) }
        startMenu = ScrollView(this).apply {
            visibility = View.GONE; addView(grid)
            background = GradientDrawable().apply { setColor(0xF0202830.toInt()); cornerRadius = dp(14).toFloat() }
        }
        root.addView(startMenu, FrameLayout.LayoutParams(dp(360), dp(440), Gravity.BOTTOM or Gravity.START)
            .apply { bottomMargin = dp(58); leftMargin = dp(8) })

        // 작업표시줄
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xE61A1A1A.toInt()); setPadding(dp(8), 0, dp(8), 0)
        }
        bar.addView(Button(this).apply {
            text = "⊞"; textSize = 20f
            setOnClickListener { startMenu.visibility = if (startMenu.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        })
        tasks = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        bar.addView(tasks, LinearLayout.LayoutParams(0, -1, 1f))
        bar.addView(TextClock(this).apply {
            format12Hour = "a h:mm\nM월 d일"; format24Hour = "HH:mm\nM월 d일"
            setTextColor(0xFFFFFFFF.toInt()); textSize = 12f; gravity = Gravity.CENTER; setPadding(dp(8), 0, dp(8), 0)
        })
        bar.addView(Button(this).apply { text = "끄기"; setOnClickListener { finish() } })
        root.addView(bar, FrameLayout.LayoutParams(-1, dp(52), Gravity.BOTTOM))
        setContentView(root)
    }

    private fun pm() = packageManager

    private fun bcell(emoji: String, label: String, f: () -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        layoutParams = GridLayout.LayoutParams().apply { width = dp(80); height = dp(86) }
        addView(TextView(context).apply { text = emoji; textSize = 30f; gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(44), dp(44)))
        addView(TextView(context).apply { text = label; textSize = 11f; setTextColor(-1); gravity = Gravity.CENTER })
        setOnClickListener { startMenu.visibility = View.GONE; f() }
    }

    private fun builtins(): List<View> = listOf(
        bcell("📝", "메모장") { open("메모장", Builtins.notepad(this)) },
        bcell("🧮", "계산기") { open("계산기", Builtins.calc(this), 260, 380) },
        bcell("🌐", "브라우저") { open("브라우저", Builtins.browser(this), 520, 420) })

    fun open(title: String, content: View, wDp: Int = 420, hDp: Int = 320) {
        val dm = resources.displayMetrics
        val w = minOf(dp(wDp), dm.widthPixels - dp(20)); val h = minOf(dp(hDp), dm.heightPixels - dp(100))
        val off = (wcount++ % 6) * dp(32)
        val win = Win(this, title, content, w, h, dp(70) + off, dp(20) + off)
        wins.add(win); winLayer.addView(win)
        win.chip = TextView(this).apply {
            text = title; setTextColor(-1); textSize = 12f; gravity = Gravity.CENTER; setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener { if (win.visibility == View.VISIBLE && focusedWin === win) win.minimize() else focus(win) }
        }
        tasks.addView(win.chip, LinearLayout.LayoutParams(-2, dp(40)).apply { rightMargin = dp(4) })
        focus(win)
    }

    fun focus(w: Win) { w.visibility = View.VISIBLE; w.bringToFront(); focusedWin = w; refreshChips() }
    fun onMinimized(w: Win) { if (focusedWin === w) focusedWin = null; refreshChips() }
    fun closeWin(w: Win) {
        winLayer.removeView(w); tasks.removeView(w.chip); wins.remove(w)
        if (focusedWin === w) focusedWin = null; refreshChips()
    }
    private fun refreshChips() = wins.forEach { it.chip.setBackgroundColor(if (it === focusedWin) 0xFF3A6EA5.toInt() else 0x33FFFFFF) }

    private fun cell(ri: ResolveInfo, color: Int): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        layoutParams = GridLayout.LayoutParams().apply { width = dp(80); height = dp(86) }
        addView(ImageView(context).apply { setImageDrawable(ri.loadIcon(pm())) }, LinearLayout.LayoutParams(dp(44), dp(44)))
        addView(TextView(context).apply {
            text = ri.loadLabel(pm()); textSize = 11f; setTextColor(color); maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END; gravity = Gravity.CENTER
        })
        setOnClickListener { launch(ri) }
    }

    private fun launch(ri: ResolveInfo) {
        startMenu.visibility = View.GONE
        val dm = resources.displayMetrics
        val w = (dm.widthPixels * 0.6).toInt()
        val h = ((dm.heightPixels - dp(52)) * 0.7).toInt()
        val l = dp(90) + (count % 6) * dp(36)
        val t = dp(24) + (count % 6) * dp(36)
        count++
        val opts = ActivityOptions.makeBasic().setLaunchBounds(Rect(l, t, l + w, t + h))
        try { // 자유 형식(창) 모드 강제 요청 (기기에 따라 무시될 수 있음)
            ActivityOptions::class.java.getMethod("setLaunchWindowingMode", Int::class.javaPrimitiveType).invoke(opts, 5)
        } catch (_: Throwable) {}
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(ri.activityInfo.packageName, ri.activityInfo.name)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(i, opts.toBundle()) } catch (e: Exception) {
            Toast.makeText(this, "실행할 수 없는 앱입니다", Toast.LENGTH_SHORT).show(); return
        }
        if (opened.add(ri.activityInfo.packageName)) {
            tasks.addView(ImageView(this).apply {
                setImageDrawable(ri.loadIcon(pm())); setPadding(dp(6), dp(6), dp(6), dp(6))
                setOnClickListener { launch(ri) }
            }, LinearLayout.LayoutParams(dp(44), dp(44)))
        }
    }

    @Deprecated("back")
    override fun onBackPressed() { startMenu.visibility = View.GONE }

    override fun onDestroy() { if (instance === this) instance = null; super.onDestroy() }
}
