package com.windowdesk

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class DexTileService : TileService() {
    override fun onStartListening() = refresh()
    override fun onClick() {
        val d = DesktopActivity.instance
        if (d != null) d.finish()
        else startActivityAndCollapse(Intent(this, DesktopActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        refresh()
    }
    private fun refresh() {
        qsTile?.apply {
            state = if (DesktopActivity.instance != null) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            label = "데스크톱 모드"; updateTile()
        }
    }
}
