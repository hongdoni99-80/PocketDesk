package com.windowdesk

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var sw: Switch
    private var syncing = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(p, p * 2, p, p) }
        col.addView(TextView(this).apply { text = "윈도우 데스크"; textSize = 26f })
        sw = Switch(this).apply {
            text = "데스크톱 모드 켜기/끄기"; textSize = 18f; setPadding(0, p, 0, p)
            setOnCheckedChangeListener { _, on ->
                if (syncing) return@setOnCheckedChangeListener
                if (on) startActivity(Intent(this@MainActivity, DesktopActivity::class.java))
                else DesktopActivity.instance?.finish()
            }
        }
        col.addView(sw)
        val free = packageManager.hasSystemFeature("android.software.freeform_window_management")
        col.addView(TextView(this).apply {
            text = (if (free) "✅ 이 기기는 창 모드를 지원합니다.\n\n" else "⚠️ 창 모드가 꺼져 있습니다. PC에서 아래 명령을 한 번 실행하고 재부팅하세요.\n\n") +
                "adb shell settings put global enable_freeform_support 1\n" +
                "adb shell settings put global force_resizable_activities 1\n\n" +
                "또는 개발자 옵션에서 '자유 형식 창 사용'과 '활동을 크기 조정 가능하게 강제 설정'을 켜세요.\n\n" +
                "빠른 설정(상단바) 편집에서 '데스크톱 모드' 타일을 추가하면 어디서든 켜고 끌 수 있습니다."
        })
        col.addView(Button(this).apply {
            text = "개발자 옵션 열기"
            setOnClickListener { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
        })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        syncing = true; sw.isChecked = DesktopActivity.instance != null; syncing = false
    }
}
