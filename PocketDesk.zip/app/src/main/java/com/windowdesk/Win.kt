package com.windowdesk

import android.annotation.SuppressLint
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*

/** PC처럼 제목 표시줄(이동/더블탭 최대화), 최소화·최대화·닫기, 크기 조절이 되는 창 */
@SuppressLint("ClickableViewAccessibility")
class Win(val act: DesktopActivity, val title: String, content: View, w: Int, h: Int, x: Int, y: Int) : FrameLayout(act) {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private var maxed = false
    private var saved = IntArray(4)
    lateinit var chip: TextView

    init {
        background = GradientDrawable().apply { setColor(0xFF2B3A55.toInt()); cornerRadius = dp(8).toFloat(); setStroke(dp(1), 0xFF5A6C8F.toInt()) }
        elevation = dp(8).toFloat()
        layoutParams = LayoutParams(w, h).apply { leftMargin = x; topMargin = y }

        val body = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(act).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), 0, 0, 0) }
        bar.addView(TextView(act).apply { text = title; setTextColor(-1); textSize = 14f; maxLines = 1; gravity = Gravity.CENTER_VERTICAL },
            LinearLayout.LayoutParams(0, -1, 1f))
        fun btn(t: String, f: () -> Unit) = TextView(act).apply {
            text = t; setTextColor(-1); textSize = 16f; gravity = Gravity.CENTER; setOnClickListener { f() }
        }
        bar.addView(btn("—") { minimize() }, LinearLayout.LayoutParams(dp(40), -1))
        bar.addView(btn("□") { toggleMax() }, LinearLayout.LayoutParams(dp(40), -1))
        bar.addView(btn("✕") { act.closeWin(this) }.apply { setBackgroundColor(0xFFC0392B.toInt()) }, LinearLayout.LayoutParams(dp(40), -1))
        body.addView(bar, LinearLayout.LayoutParams(-1, dp(38)))
        body.addView(content, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(dp(1), 0, dp(1), dp(1)) })
        addView(body, LayoutParams(-1, -1))

        // 제목 표시줄 드래그 + 더블탭 최대화
        val gd = GestureDetector(act, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onDoubleTap(e: MotionEvent): Boolean { toggleMax(); return true }
        })
        var dx = 0f; var dy = 0f; var ox = 0; var oy = 0
        bar.setOnTouchListener { _, e ->
            gd.onTouchEvent(e)
            val lp = layoutParams as LayoutParams
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; ox = lp.leftMargin; oy = lp.topMargin }
                MotionEvent.ACTION_MOVE -> if (!maxed) {
                    lp.leftMargin = ox + (e.rawX - dx).toInt(); lp.topMargin = maxOf(0, oy + (e.rawY - dy).toInt()); layoutParams = lp
                }
            }
            true
        }
        // 오른쪽 아래 모서리 크기 조절
        var w0 = 0; var h0 = 0
        val grip = TextView(act).apply { text = "◢"; setTextColor(0xFFAAB8D0.toInt()); gravity = Gravity.CENTER }
        grip.setOnTouchListener { _, e ->
            val lp = layoutParams as LayoutParams
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; w0 = width; h0 = height }
                MotionEvent.ACTION_MOVE -> if (!maxed) {
                    lp.width = maxOf(dp(220), w0 + (e.rawX - dx).toInt()); lp.height = maxOf(dp(160), h0 + (e.rawY - dy).toInt()); layoutParams = lp
                }
            }
            true
        }
        addView(grip, LayoutParams(dp(28), dp(28), Gravity.BOTTOM or Gravity.END))
    }

    fun minimize() { visibility = View.GONE; act.onMinimized(this) }

    fun toggleMax() {
        val lp = layoutParams as LayoutParams
        if (!maxed) {
            saved = intArrayOf(lp.leftMargin, lp.topMargin, lp.width, lp.height)
            lp.leftMargin = 0; lp.topMargin = 0; lp.width = -1; lp.height = -1
        } else {
            lp.leftMargin = saved[0]; lp.topMargin = saved[1]; lp.width = saved[2]; lp.height = saved[3]
        }
        maxed = !maxed; layoutParams = lp
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_DOWN) act.focus(this)
        return super.dispatchTouchEvent(ev)
    }
}
